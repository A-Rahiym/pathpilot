import 'package:flutter/material.dart';
import 'widgets/main_nav.dart';
// import 'package:flutter_dotenv/flutter_dotenv.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await dotenv.load(fileName: ".env");
  runApp(const MaterialApp(home: MainNav(), debugShowCheckedModeBanner: false));
}
