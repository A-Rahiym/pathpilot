import 'dart:convert';
import 'package:http/http.dart' as http;

class CommandResult {
  final String? intent;
  final String? destination;

  CommandResult({this.intent, this.destination});
}

class GeminiService {
  // Helper to clean Gemini's reply from code block markers
  String cleanJson(String text) {
    final regex = RegExp(r'```(?:json)?([\s\S]*?)```');
    final match = regex.firstMatch(text);
    if (match != null) {
      return match.group(1)!.trim();
    }
    return text.trim();
  }

  /// Parses a voice command using Gemini LLM API and extracts intent/destination.
  Future<CommandResult> parseCommandLLM(String command, String apiKey) async {
    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey',
    );
    final prompt =
        """
You are a navigation assistant using google_maps for visually impaired users.
Extract the navigation intent and destination from this command.
Always reply with a valid, specific 'destination' (e.g., 'current location', 'senate building', 'library').
If the user asks for their location, set destination to 'current location'.
Reply ONLY with a valid JSON object containing 'intent' and 'destination', no explanation or formatting.
Command: $command
""";
    final body = jsonEncode({
      "contents": [
        {
          "parts": [
            {"text": prompt},
          ],
        },
      ],
    });
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: body,
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final text =
          data['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '';
      print('Gemini raw reply: $text');
      final cleanedText = cleanJson(text);
      print('Gemini cleaned reply: $cleanedText');
      try {
        final jsonReply = jsonDecode(cleanedText);
        return CommandResult(
          intent: jsonReply['intent'],
          destination: jsonReply['destination'],
        );
      } catch (e) {
        print('Gemini JSON parse error: $e');
        return CommandResult();
      }
    } else {
      // API error
      return CommandResult();
    }
  }

  Future<Map<String, dynamic>> getMapsGroundedDirections({
    required String apiKey,
    required double userLat,
    required double userLng,
    required String destination,
  }) async {
    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey',
    );

    final prompt =
        "My current location is at latitude $userLat longitude $userLng. Please guide me to $destination.";

    final body = jsonEncode({
      "contents": [
        {
          "role": "user",
          "parts": [
            {"text": prompt},
          ],
        },
      ],
      "tools": [
        {
          "googleMaps": {"enableWidget": true},
        },
      ],
      "toolConfig": {
        "retrievalConfig": {
          "latLng": {"latitude": userLat, "longitude": userLng},
        },
      },
    });

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      // You may get: data['candidates'][0]['content']['parts'][0]['text'] (instructions)
      // And: data['groundingMetadata'] (links, sources)
      // And: data['googleMapsWidgetContextToken'] (for widget)
      return data;
    } else {
      print('Gemini Maps Grounding API error: ${response.statusCode}');
      return {};
    }
  }
}
