import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import '../widgets/custom_map.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../services/speech_to_text_service.dart';
import '../services/gemini_service.dart';
import '../services/tts_service.dart';
import '../services/camera_gemini_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:convert';
import 'dart:async';
import 'package:camera/camera.dart';
import 'package:http/http.dart' as http;
import 'dart:math';
import 'package:async_queue/async_queue.dart'; // using async_queue package

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  // --- Services ---
  final SpeechToTextService _speechService = SpeechToTextService();
  final GeminiService _geminiService = GeminiService();
  final TtsService _ttsService = TtsService();
  final CameraGeminiService _cameraGeminiService = CameraGeminiService();

  // --- Search Controller ---
  final TextEditingController _searchController = TextEditingController();
  List<Location> _searchResults = [];
  bool _showSearchResults = false;

  // --- Hardcoded Gemini API Key ---
  final String geminiApiKey = 'AIzaSyA6FEDQZPQPnVbPnvtYZB-m0qFohD93f18';
  final String googleMapsApiKey = 'AIzaSyC_p8YHhBBEjDMsniEZYd4vzF73QEaGY7o';

  late final AsyncQueue _frameAsyncQueue;
  late GoogleMapController mapController;
  final LatLng _center = const LatLng(11.15, 7.65); // ABU Zaria
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  bool _isListening = false;
  String _cameraAiResponse = "";
  bool _cameraStreaming = false;
  Timer? _cameraStreamTimer;
  String? _pendingSearch; // Store last searched destination

  // --- Settings ---
  bool _voiceGuidance = true; // Default, can be loaded from persistent storage

  @override
  void initState() {
    super.initState();
    _frameAsyncQueue = AsyncQueue();
    _requestMicPermission();
    _speechService.init();
    _initCameraAndGemini();
    _initMotionDetection();
    _loadSettings();
  }

  void _loadSettings() {
    // TODO: Load from persistent storage if needed
    // For now, just set default
    setState(() {
      _voiceGuidance = true;
    });
  }

  void _initMotionDetection() {
    try {
      userAccelerometerEventStream().listen(
        (event) {
          double magnitude = sqrt(
            event.x * event.x + event.y * event.y + event.z * event.z,
          );
          if (magnitude > 2.0 && !_cameraStreaming) {
            print('Motion detected: $magnitude');
            _startCameraStreaming();
          }
        },
        onError: (error) {
          print('UserAccelerometer error: $error');
        },
        cancelOnError: true,
      );
    } catch (e) {
      print('Motion detection setup error: $e');
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  // Search locations by query (real-time search)
  Future<void> _searchLocationsByQuery(String query) async {
    try {
      final results = await locationFromAddress(query);
      setState(() {
        _searchResults = results.take(5).toList();
        _showSearchResults = results.isNotEmpty;
      });
    } catch (e) {
      print('Search error: $e');
      setState(() {
        _searchResults = [];
        _showSearchResults = false;
      });
    }
  }

  // Select a search result by coordinates
  Future<void> _selectSearchResultByLatLng(Location location) async {
    // final destLatLng = LatLng(location.latitude, location.longitude);

    // Get reverse geocoding to get location name
    try {
      final placemarks = await placemarkFromCoordinates(
        location.latitude,
        location.longitude,
      );
      final placeName = placemarks.isNotEmpty
          ? placemarks.first.name ?? 'Unknown Location'
          : 'Unknown Location';

      _pendingSearch = placeName;
      _searchController.text = placeName;
    } catch (e) {
      _pendingSearch = '${location.latitude}, ${location.longitude}';
      _searchController.text = _pendingSearch!;
    }

    setState(() {});
  }

  // Handle navigation to selected search result
  // Future<void> _handleNavigationToSearch() async {
  //   if (_pendingSearch == null) return;

  //   try {
  //     Position position = await Geolocator.getCurrentPosition(
  //       locationSettings: LocationSettings(
  //         accuracy: LocationAccuracy.high,
  //         distanceFilter: 0,
  //       ),
  //     );

  //     // Get coordinates from search query
  //     final results = await locationFromAddress(_pendingSearch!);
  //     if (results.isEmpty) {
  //       if (_voiceGuidance) {
  //         await _ttsService.speak('Location not found');
  //       }
  //       return;
  //     }

  //     final searchLocation = results.first;
  //     final destLatLng = LatLng(
  //       searchLocation.latitude,
  //       searchLocation.longitude,
  //     );
  //     final originLatLng = LatLng(position.latitude, position.longitude);

  //     // Get route
  //     List<LatLng> routePoints = await _getRoutePoints(
  //       originLatLng,
  //       destLatLng,
  //     );

  //     setState(() {
  //       _markers.clear();
  //       _markers.add(
  //         Marker(
  //           markerId: MarkerId('destination'),
  //           position: destLatLng,
  //           infoWindow: InfoWindow(title: _pendingSearch ?? 'Destination'),
  //         ),
  //       );
  //       _polylines.clear();
  //       if (routePoints.isNotEmpty) {
  //         _polylines.add(
  //           Polyline(
  //             polylineId: PolylineId('route'),
  //             color: Colors.blueAccent,
  //             width: 6,
  //             points: routePoints,
  //           ),
  //         );
  //       }
  //     });

  //     mapController.animateCamera(CameraUpdate.newLatLngZoom(destLatLng, 15));

  //     if (_voiceGuidance) {
  //       await _ttsService.speak(
  //         'Navigating to ${_pendingSearch ?? 'destination'}',
  //       );
  //     }

  //     _searchController.clear();
  //     _pendingSearch = null;
  //     setState(() => _showSearchResults = false);
  //   } catch (e) {
  //     print('Navigation error: $e');
  //     if (_voiceGuidance) {
  //       await _ttsService.speak('Could not navigate to this location');
  //     }
  //   }
  // }

  // Select search result by text
  void _selectSearchResult(String query) {
    _pendingSearch = query;
    setState(() {
      _showSearchResults = false;
      _searchResults = [];
    });
  }

  Future<void> _initCameraAndGemini() async {
    await _cameraGeminiService.initCamera();

    _cameraGeminiService.onAiResponse = (response) async {
      // Update the UI with the latest text from the AI
      setState(() => _cameraAiResponse = response);

      // Mark TTS as busy to pause the camera analysis loop
      _cameraGeminiService.ttsBusy = true;

      // Speak the AI's response if voice guidance is on
      if (_voiceGuidance) {
        // Stop any currently playing speech to prioritize this new alert
        await _ttsService.stop();
        await _ttsService.speak(response);
      }

      // Reset the busy flag so camera analysis can resume
      _cameraGeminiService.ttsBusy = false;
    };

    setState(() {});
  }

  // Update _startCameraStreaming to NOT require destination
  Future<void> _startCameraStreaming() async {
    if (!_cameraGeminiService.isInitialized) {
      if (_voiceGuidance) {
        await _ttsService.speak('Camera not ready');
      }
      return;
    }

    setState(() => _cameraStreaming = true);
    if (_voiceGuidance) {
      await _ttsService.speak('Obstacle detection started');
    }

    _cameraStreamTimer?.cancel();
    _cameraStreamTimer = Timer.periodic(const Duration(milliseconds: 2500), (
      timer,
    ) async {
      if (!_cameraStreaming || !mounted) {
        timer.cancel();
        return;
      }

      if (!_cameraGeminiService.ttsBusy) {
        // Queue frame processing - AsyncJob requires a parameter (previous result)
        _frameAsyncQueue.addJob((previousResult) async {
          await _cameraGeminiService.captureAndAnalyze();
        });
      }
    });
  }

  // Add stop method
  Future<void> _stopCameraStreaming() async {
    setState(() => _cameraStreaming = false);
    _cameraStreamTimer?.cancel();
    await _cameraGeminiService.session?.close();
    if (_voiceGuidance) {
      await _ttsService.speak('Obstacle detection stopped');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF232323),
      body: SafeArea(
        child: Stack(
          children: [
            // Map with rounded corners
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: CustomMap(
                  center: _center,
                  onMapCreated: _onMapCreated,
                  markers: _markers,
                  polylines: _polylines,
                ),
              ),
            ),
            // Search bar overlay
            Positioned(
              top: 24,
              left: 24,
              right: 24,
              child: Column(
                children: [
                  Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF232323),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Search destination',
                              hintStyle: const TextStyle(color: Colors.white54),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16,
                              ),
                            ),
                            onChanged: (value) async {
                              if (value.isEmpty) {
                                setState(() {
                                  _showSearchResults = false;
                                  _searchResults = [];
                                });
                              } else {
                                await _searchLocationsByQuery(value);
                              }
                            },
                            onSubmitted: (value) {
                              if (value.isNotEmpty) {
                                _selectSearchResult(value);
                              }
                            },
                          ),
                        ),
                        if (_pendingSearch != null)
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF2196F3),
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(horizontal: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text('Navigate'),
                            onPressed: () async {
                              await _handleLocationRequest(_pendingSearch!);
                              _pendingSearch = null;
                              setState(() => _showSearchResults = false);
                            },
                          ),
                        IconButton(
                          icon: Icon(
                            _isListening ? Icons.mic : Icons.mic_none,
                            color: Colors.white,
                          ),
                          onPressed: _isListening
                              ? _stopListening
                              : _manualStartListening,
                        ),
                      ],
                    ),
                  ),
                  // Search results dropdown
                  if (_showSearchResults && _searchResults.isNotEmpty)
                    Container(
                      margin: EdgeInsets.only(top: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF232323),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white24),
                      ),
                      constraints: BoxConstraints(maxHeight: 200),
                      child: ListView.builder(
                        itemCount: _searchResults.length,
                        itemBuilder: (context, index) {
                          final result = _searchResults[index];
                          return ListTile(
                            title: Text(
                              '${result.latitude.toStringAsFixed(4)}, ${result.longitude.toStringAsFixed(4)}',
                              style: const TextStyle(color: Colors.white),
                            ),
                            onTap: () async {
                              _searchController.text =
                                  '${result.latitude}, ${result.longitude}';
                              await _selectSearchResultByLatLng(result);
                              setState(() => _showSearchResults = false);
                            },
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
            // Floating controls (zoom and orientation)
            Positioned(
              right: 24,
              bottom: 120,
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  _mapControlButton(Icons.explore, () {
                    mapController.animateCamera(
                      CameraUpdate.newCameraPosition(
                        CameraPosition(
                          target: _center,
                          zoom: 12,
                          tilt: 0,
                          bearing: 0,
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
            // Listening indicator
            if (_isListening)
              Positioned(
                bottom: 40,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      'Listening...',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            // Camera preview and controls
            Positioned(
              bottom: 24,
              left: 24,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 120,
                    height: 160,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child:
                        _cameraGeminiService.controller != null &&
                            _cameraGeminiService.controller!.value.isInitialized
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: CameraPreview(
                              _cameraGeminiService.controller!,
                            ),
                          )
                        : const Center(child: CircularProgressIndicator()),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: 120,
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _cameraAiResponse,
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    mini: true,
                    onPressed: () async {
                      if (_cameraStreaming) {
                        await _stopCameraStreaming();
                      } else {
                        await _startCameraStreaming();
                      }
                    },
                    tooltip: _cameraStreaming
                        ? 'Stop Detection'
                        : 'Start Detection',
                    backgroundColor: _cameraStreaming
                        ? Colors.red
                        : Colors.blue,
                    child: Icon(
                      _cameraStreaming
                          ? Icons.visibility_off
                          : Icons.visibility,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _mapControlButton(IconData icon, VoidCallback onPressed) {
    return Material(
      color: const Color(0xFF232323),
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onPressed,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, color: Colors.white),
        ),
      ),
    );
  }

  // --- Unified location handling ---
  Future<void> _handleLocationRequest(String destination) async {
    if (destination.toLowerCase() == 'current location') {
      try {
        Position position = await Geolocator.getCurrentPosition(
          locationSettings: LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 0,
          ),
        );
        List<Placemark> placemarks = await placemarkFromCoordinates(
          position.latitude,
          position.longitude,
        );
        String address;
        if (placemarks.isNotEmpty) {
          final place = placemarks.first;
          address =
              '${place.name ?? ''}, ${place.street ?? ''}, ${place.locality ?? ''}, ${place.administrativeArea ?? ''}, ${place.country ?? ''}';
        } else {
          address = 'Unknown address';
        }
        if (_voiceGuidance) {
          await _ttsService.speak('Your current location is $address.');
        }
        final LatLng latLng = LatLng(position.latitude, position.longitude);
        setState(() {
          _markers.clear();
          _markers.add(
            Marker(
              markerId: MarkerId('current_location'),
              position: latLng,
              infoWindow: InfoWindow(title: 'Current Location'),
            ),
          );
        });
        mapController.animateCamera(CameraUpdate.newLatLngZoom(latLng, 15));
      } catch (e) {
        if (_voiceGuidance) {
          await _ttsService.speak(
            'Sorry, I could not fetch your current location.',
          );
        }
      }
    } else {
      if (_voiceGuidance) await _ttsService.speak('Navigating to $destination');
      await _searchLocation(destination);
      await _startCameraStreaming();
    }
  }

  Future<void> _searchLocation(String query) async {
    try {
      List<Location> locations = await locationFromAddress(query);
      if (locations.isNotEmpty) {
        final location = locations.first;
        final LatLng destLatLng = LatLng(location.latitude, location.longitude);

        // Get current location for route
        Position position = await Geolocator.getCurrentPosition(
          locationSettings: LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 0,
          ),
        );
        final LatLng originLatLng = LatLng(
          position.latitude,
          position.longitude,
        );

        // Draw route polyline
        List<LatLng> routePoints = await _getRoutePoints(
          originLatLng,
          destLatLng,
        );

        setState(() {
          _markers.clear();
          _markers.add(
            Marker(
              markerId: MarkerId('searched_location'),
              position: destLatLng,
              infoWindow: InfoWindow(title: query),
            ),
          );
          _polylines.clear();
          if (routePoints.isNotEmpty) {
            _polylines.add(
              Polyline(
                polylineId: PolylineId('route'),
                color: Colors.blueAccent,
                width: 6,
                points: routePoints,
              ),
            );
          }
          _pendingSearch = query;
        });
        mapController.animateCamera(CameraUpdate.newLatLngZoom(destLatLng, 15));
        if (_voiceGuidance) await _ttsService.speak('Navigating to $query');
        await _startCameraStreaming();
      }
    } catch (e) {
      if (_voiceGuidance) {
        await _ttsService.speak('Sorry, I could not find $query');
      }
    }
  }

  // Fetch route via Google Directions API and decode the overview_polyline
  // Example for Directions API
  Future<List<LatLng>> _getRoutePoints(
    LatLng origin,
    LatLng destination,
  ) async {
    try {
      final String originStr = '${origin.latitude},${origin.longitude}';
      final String destStr = '${destination.latitude},${destination.longitude}';
      final String key = googleMapsApiKey;
      final String url =
          'https://maps.googleapis.com/maps/api/directions/json?origin=$originStr&destination=$destStr&key=$key&mode=walking';

      final response = await http.get(Uri.parse(url));
      if (response.statusCode != 200) {
        print('Directions API error: ${response.statusCode}');
        return [];
      }

      final Map<String, dynamic> data = json.decode(response.body);
      if ((data['routes'] as List).isEmpty) return [];

      final overview = data['routes'][0]['overview_polyline']?['points'];
      if (overview == null || (overview as String).isEmpty) return [];

      return _decodePolyline(overview);
    } catch (e) {
      print('Directions API exception: $e');
      return [];
    }
  }

  // Decode an encoded polyline string into a list of LatLng
  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> points = [];
    int index = 0;
    int len = encoded.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int b;
      int shift = 0;
      int result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0) ? ~(result >> 1) : (result >> 1);
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1F) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0) ? ~(result >> 1) : (result >> 1);
      lng += dlng;

      points.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return points;
  }

  void _showDetectedCommandDialog(String command) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black87,
        content: Text(
          'Detected command:\n$command',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }
    });
  }

  void _manualStartListening() async {
    setState(() {
      _isListening = true;
    });
    if (_voiceGuidance) await _ttsService.speak('Listening...');
    await _speechService.listen(
      onResult: (recognizedText) async {
        setState(() {
          _isListening = false;
        });
        _showDetectedCommandDialog(recognizedText);

        // Use Gemini Maps Grounding API for navigation
        await _handleConversationalNavigation(recognizedText);
      },
      onError: (error) async {
        setState(() {
          _isListening = false;
        });
        if (_voiceGuidance) {
          await _ttsService.speak('Speech recognition error: $error');
        }
      },
    );
  }

  Future<void> _handleConversationalNavigation(String command) async {
    try {
      // 1. Get current location
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 0,
        ),
      );
      final userLat = position.latitude;
      final userLng = position.longitude;

      // 2. Call Gemini Maps Grounding API
      final result = await _geminiService.getMapsGroundedDirections(
        apiKey: geminiApiKey,
        userLat: userLat,
        userLng: userLng,
        destination: command,
      );

      final instructions =
          result['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '';
      final groundingMetadata = result['groundingMetadata'];

      setState(() {
        _cameraAiResponse = instructions;
      });

      if (_voiceGuidance && instructions.isNotEmpty) {
        await _ttsService.speak(instructions);
      }

      // 3. Extract destination coordinates and estimated time
      LatLng? destLatLng;
      String? etaText;
      if (groundingMetadata != null) {
        if (groundingMetadata['destinationLatLng'] != null) {
          final lat = groundingMetadata['destinationLatLng']['latitude'];
          final lng = groundingMetadata['destinationLatLng']['longitude'];
          destLatLng = LatLng(lat, lng);
        }
        if (groundingMetadata['estimatedTime'] != null) {
          etaText = groundingMetadata['estimatedTime'];
        }
      }

      // 4. Update map with marker, polyline, and ETA
      if (destLatLng != null) {
        final LatLng destinationLatLng = destLatLng; // Non-nullable promotion

        setState(() {
          _markers.clear();
          _markers.add(
            Marker(
              markerId: MarkerId('destination'),
              position: destinationLatLng,
              infoWindow: InfoWindow(
                title: 'Target Destination',
                snippet: etaText ?? '',
              ),
            ),
          );
        });
        mapController.animateCamera(
          CameraUpdate.newLatLngZoom(destinationLatLng, 15),
        );

        // Draw polyline from current position to destination
        final originLatLng = LatLng(userLat, userLng);
        List<LatLng> routePoints = await _getRoutePoints(
          originLatLng,
          destinationLatLng, // Use non-nullable variable here
        );
        setState(() {
          _polylines.clear();
          if (routePoints.isNotEmpty) {
            _polylines.add(
              Polyline(
                polylineId: PolylineId('route'),
                color: Colors.blueAccent,
                width: 6,
                points: routePoints,
              ),
            );
          }
        });

        // Optionally, speak ETA
        if (_voiceGuidance && etaText != null && etaText.isNotEmpty) {
          await _ttsService.speak('Estimated time to destination is $etaText');
        }
      }
    } catch (e) {
      print('Error in conversational navigation: $e');
      if (_voiceGuidance) {
        await _ttsService.speak('Sorry, I could not get directions.');
      }
    }
  }

  void _stopListening() async {
    await _speechService.stop();
    setState(() {
      _isListening = false;
    });
    if (_voiceGuidance) await _ttsService.speak('Stopped listening.');
  }

  Future<void> _requestMicPermission() async {
    var status = await Permission.microphone.request();
    if (status.isDenied || status.isPermanentlyDenied) {
      if (_voiceGuidance) {
        await _ttsService.speak(
          'Microphone permission denied. Please enable it in settings.',
        );
      }
      if (status.isPermanentlyDenied) {
        await openAppSettings();
      }
    }
  }

  @override
  void dispose() {
    _searchController.dispose(); // TextField controller
    _cameraGeminiService.dispose(); // Camera and Gemini service
    _cameraStreamTimer?.cancel(); // Timer for camera streaming
    _speechService.stop(); // Stop speech service
    _ttsService.stop(); // Stop TTS service
    mapController.dispose(); // Map controller
    _frameAsyncQueue.stop();
    super.dispose();
  }
  // Future<void> _getConversationalDirections(String destination) async {
  //   try {
  //     Position position = await Geolocator.getCurrentPosition(
  //       locationSettings: LocationSettings(
  //         accuracy: LocationAccuracy.high,
  //         distanceFilter: 0,
  //       ),
  //     );
  //     final userLat = position.latitude;
  //     final userLng = position.longitude;

  //     final geminiService = GeminiService();
  //     final result = await geminiService.getMapsGroundedDirections(
  //       apiKey: geminiApiKey,
  //       userLat: userLat,
  //       userLng: userLng,
  //       destination: destination,
  //     );

  //     final instructions =
  //         result['candidates']?[0]?['content']?['parts']?[0]?['text'] ?? '';
  //     final widgetToken = result['googleMapsWidgetContextToken'];
  //     final groundingMetadata = result['groundingMetadata'];

  //     // Show instructions in your UI
  //     setState(() {
  //       _cameraAiResponse = instructions;
  //     });

  //     if (_voiceGuidance && instructions.isNotEmpty) {
  //       await _ttsService.speak(instructions);
  //     }

  //     // TODO: If widgetToken is present, show a WebView or custom widget for the map
  //     // TODO: Use groundingMetadata for attribution/links if required
  //   } catch (e) {
  //     print('Error getting conversational directions: $e');
  //     if (_voiceGuidance) {
  //       await _ttsService.speak('Sorry, I could not get directions.');
  //     }
  //   }
  // }
}
